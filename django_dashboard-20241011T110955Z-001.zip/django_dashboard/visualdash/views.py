from django.shortcuts import render, redirect
from .models import VisualDashboard
import json
from django.contrib import auth, messages
from .forms import LoginForm
# Create your views here.

def import_data(request):
    if request.method == 'POST' and request.FILES['json_file']:
        json_file = request.FILES['json_file']
        data = json.load(json_file)
        for item in data:
            visualdashboard = VisualDashboard(
                          title=item['title'],
                          insight=item['insight'],
                          url=item['url'],
                          topic=item['topic'],
                          sector=item['sector'],
                          region=item['region'],
                          country=item['country'],
                          intensity=item['intensity'],
                          likelihood=item['likelihood'],
                          relevance=item['relevance'],
                          pestle=item['pestle'],
                          source=item['source'],
                          added=item['added'],
                          published=item['published'],
                          start_year=item['start_year'],
                          end_year=item['end_year'],
                          impact=item['impact'],
            )
            visualdashboard.save()
        return render(request, 'success.html')
    return render(request, 'form.html')

def index(request):
    vdata= VisualDashboard.objects.all()
    context = {
        "vdata": vdata
        
    }

    return render(request, 'index.html', context)
    
def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            return redirect('index')
        else:
            messages.error(request, 'Invalid login details')
    return render(request, 'loginapp/login.html', {'form': LoginForm})

def logout(request):
    auth.logout(request)
    messages.info(request, 'You have been logged out!!')
    return redirect('/')