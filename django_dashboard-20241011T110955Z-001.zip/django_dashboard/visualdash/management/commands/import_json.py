import json
from django.core.management.base import BaseCommand
from visualdash.models import VisualDashboard


class Command(BaseCommand):
    help = 'Import external JSON file data into Django database'
    def handle(self, *args, **kwargs):
        with open(r'E:\practice\New folder\djanvisual\django_dashboard\jsondata.json','r' , encoding='utf8') as file:
                data = json.load(file)
                

                for item in data:
                     VisualDashboard.objects.create(
                          title=item['title'],
                          insight=item['insight'],
                          url=item['url'],
                          topic=item['topic'],
                          sector=item['sector'],
                          region=item['region'],
                          country=item['country'],
                          intensity=item['intensity'],
                          likelihood=item['likelihood'],
                          relevance=item['relevance'],
                          pestle=item['pestle'],
                          source=item['source'],
                          added=item['added'],
                          published=item['published'],
                          start_year=item['start_year'],
                          end_year=item['end_year'],
                          impact=item['impact'],
                     )
        self.stdout.write(self.style.SUCCESS('Done'))