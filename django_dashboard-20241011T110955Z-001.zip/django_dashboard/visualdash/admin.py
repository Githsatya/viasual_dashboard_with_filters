from django.contrib import admin
from visualdash.models import VisualDashboard

# Register your models here.
@admin.register(VisualDashboard)
class VisualDashboardAdmin(admin.ModelAdmin):
    list_display = ['title', 
                    'insight',
                      'url',
                        'topic',
                          'sector',
                            'region',
                              'country', 
              'intensity', 
              'likelihood',
                'relevance',
                  'pestle',
                    'source', 
                    'added', 
              'published',
                'start_year',
                  'end_year',
                    'impact']
    list_per_page=50