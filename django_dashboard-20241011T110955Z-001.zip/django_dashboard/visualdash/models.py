
from django.db import models
from jsonfield import JSONField
class VisualDashboard(models.Model):

  title = models.CharField(max_length=255)
  insight = models.CharField(max_length=255)
  url = models.URLField()
  topic = models.CharField(max_length=255)
  sector = models.CharField(max_length=255)
  region = models.CharField(max_length=255)
  country = models.CharField(max_length=255, blank=True)  # Optional field since it might be empty

  intensity = models.IntegerField()
  likelihood = models.IntegerField()
  relevance = models.IntegerField()
  pestle = models.CharField(max_length=255, blank=True)  # Optional field since it might be empty
  source = models.CharField(max_length=255)

  # Store the 'added' and 'published' dates as JSON since they have a specific format
  added = JSONField(default=dict)
  published = JSONField(default=dict)

  # Dates might be empty strings, handle them gracefully during parsing (similar to previous example)
  def clean_added(self):
    data = self.added
    try:
      # Assuming the format is "Month, Day Year HH:MM:SS"
      for key in ["month", "day", "year", "hour", "minute", "second"]:
        data[key] = int(data.get(key, 0))
    except ValueError:
      pass
    return data

  def clean_published(self):
    return self.clean_added(self.published)

  # Handle empty strings for start_year and end_year
  start_year = models.CharField(max_length=4, blank=True)
  end_year = models.CharField(max_length=4, blank=True)

  impact = models.TextField(blank=True)  # Optional field since it might be empty

  def __str__(self):
    return self.title
