1 .Apply database migrations:
    python manage.py migrate

2.Create a superuser for admin access:
    python manage.py createsuperuser

3.Start the development server:
    python manage.py runserver